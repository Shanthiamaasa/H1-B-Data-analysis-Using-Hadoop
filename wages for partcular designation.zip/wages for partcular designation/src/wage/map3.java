package wage;

import java.io.IOException;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class map3 extends Mapper<LongWritable, Text, Text, FloatWritable> {

	public void map(LongWritable key, Text value, Context con)
			throws IOException, InterruptedException {
		     
		  String line[]=value.toString().split("\t");
		  if(line.length>=5){
		  String a=line[5];
		  System.out.println(a);
		 if(a.equals("Y")) {
			   if(!line[6].equals("NA")){
		    float sal =Float.parseFloat(line[6]);
		   // String state=line[24]+line[10];
		    String job =line[4];
		       con.write(new Text(job), new FloatWritable(sal));
			   }
		   }
		
	}}

}
