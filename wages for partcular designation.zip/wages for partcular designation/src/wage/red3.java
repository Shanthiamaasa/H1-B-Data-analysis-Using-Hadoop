package wage;

import java.io.IOException;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class red3 extends Reducer<Text, FloatWritable, Text, Text> {

	public void reduce(Text _key, Iterable<FloatWritable> values, Context con)
			throws IOException, InterruptedException {
		float max=0,min=Float.MAX_VALUE;String out="";
		for (FloatWritable val : values) {
           
          max=Math.max(val.get(), max);
          min=Math.min(val.get(), min);
          out=min+"-"+max;
		}
con.write(new Text(_key),new Text(out));
		
	}
	
}
