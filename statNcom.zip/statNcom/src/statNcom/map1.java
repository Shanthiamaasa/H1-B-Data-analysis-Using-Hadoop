package statNcom;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class map1 extends Mapper<LongWritable, Text, Text, Text> {

	HashMap hashMap=new HashMap(); 
	
	public void map(LongWritable key, Text value, Context con)
			throws IOException, InterruptedException {
		String line[]=value.toString().split("\t");
		if(line.length>8){
			add(line[8],line[2]);
		}	
	}
	
		public void run(Context con) throws IOException, InterruptedException {
		
		    while (con.nextKeyValue()) {
		       map(con.getCurrentKey(), con.getCurrentValue(), con);
		    }
		    end(con);
		}
		
		
	void end(Context con) throws IOException, InterruptedException{
		
			Set  s=hashMap.entrySet();
			
			Iterator iterator=s.iterator();
			while(iterator.hasNext()){
				Entry e=(Entry) iterator.next();
				con.write(new Text(e.getKey().toString()),new Text(e.getValue().toString()));
			}
		
			
			
		}
		
		void add(String key,String data){
			if(hashMap.isEmpty()){
				hashMap.put(key, data.toLowerCase());
				
			}else if(hashMap.containsKey(key)){
				
				String a[]=(hashMap.get(key)).toString().split(";");
				
				 List<String> list = Arrays.asList(a);
				 
				 if(list.contains(data.toLowerCase())){
					 
				 }else{
				
				hashMap.put(key, hashMap.get(key)+";"+data.toLowerCase());
				 }
				
			}else{
				hashMap.put(key, data.toLowerCase());
			}
			
			
		}
	}


