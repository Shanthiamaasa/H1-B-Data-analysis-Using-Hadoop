package pop;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;
import java.util.*;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.math3.ode.JacobianMatrices.MismatchedEquations;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class red6 extends Reducer<Text, Text, Text, Text> {
	
	
	
	public void reduce(Text key, Iterable<Text> values, Context con)
			throws IOException, InterruptedException {
		long count=0;
	    
		
		for (Text val : values) {
			count=count+1;
			
		}
		
		con.write(new Text(key.toString().split("\t")[0]),new Text(count+"\t"+key.toString().split("\t")[1]));
	}
	
}
