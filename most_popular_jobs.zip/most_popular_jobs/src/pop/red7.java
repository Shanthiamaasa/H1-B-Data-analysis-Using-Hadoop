package pop;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.util.*;
import java.util.Map.Entry;

public class red7 extends Reducer<Text, Text, Text, Text> {
	
	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {
	
		HashMap hashMap=new HashMap<String, Double>();
		Map<String, Double> sortedMapAsc;
		for (Text val : values) {
			String a[]=val.toString().split("\t");
			hashMap.put(a[1],Double.parseDouble(a[0]));
			
		}
		sortedMapAsc = sortByComparator(hashMap, false);
		Set  s=sortedMapAsc.entrySet();
		
		Iterator iterator=s.iterator();
		int i=0;
		while(iterator.hasNext()){
			if(i<=5){
			Entry e=(Entry) iterator.next();
			context.write(new Text(key+","+e.getKey().toString()),new Text(e.getValue().toString()));
			
		}else{
			break;
		}
			i++;
		}
		
	}
	private static Map<String, Double> sortByComparator(Map<String, Double> unsortMap, final boolean order)
    {

        List<Entry<String, Double>> list = new LinkedList<Entry<String, Double>>(unsortMap.entrySet());

        // Sorting the list based on values
        Collections.sort(list, new Comparator<Entry<String, Double>>()
        {
            public int compare(Entry<String, Double> o1,
                    Entry<String, Double> o2)
            {
                if (order)
                {
                    return o1.getValue().compareTo(o2.getValue());
                }
                else
                {
                    return o2.getValue().compareTo(o1.getValue());

                }
            }
        });

        // Maintaining insertion order with the help of LinkedList
        Map<String, Double> sortedMap = new LinkedHashMap<String, Double>();
        for (Entry<String, Double> entry : list)
        {
            sortedMap.put(entry.getKey(), entry.getValue());
           
        }

        return sortedMap;
    }

}
