package pop;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class map6 extends Mapper<LongWritable, Text, Text, Text> {

	public void map(LongWritable key, Text value, Context con)
			throws IOException, InterruptedException {
		String line[]=value.toString().split("\t");
		if(line.length>=7){
			
        String job=line[3];
        String year=line[7];
		String join=year+"\t"+job;
		if(!job.equals("NA") ){
			if(!year.equals("NA")){
			if(isNumeric(year) && year.length()==4){
			con.write(new Text(join), new Text("1"));
			}
			}
		}
		}
		
	}
	public static boolean isNumeric(String str)  
	{  
	  try  
	  {  
	    double d = Double.parseDouble(str);  
	  }  
	  catch(NumberFormatException nfe)  
	  {  
	    return false;  
	  }  
	  return true;  
	}
	
}
